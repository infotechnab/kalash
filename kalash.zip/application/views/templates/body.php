 <div class="introductionGadegt">
                         <div class="introductionNote"> <h4>Welcome ! </h4>
                             <h5>Namaste! Welcome to Kalash Restaurant. </h5>
 <p>Located in the heart of Amsterdam, just a 6 - 9 minute walk from Amsterdam 
Central Station and Dam Square, Kalash Restaurant is specialized in many 
Indian and Nepalese dishes. Enjoy the authentic taste of these two 
traditional cuisines, where herbs and spices play an important role.
Besides dinner, it is possible to have a delightful lunch at Ashoka. Signature
 dishes like freshly prepared Tandoori,
 as well as Lamb, Chicken, Seafood and authentic lentil soup are on the menu.</p></div>
                        
                         <div class="locationMap">
                             <div id="map-canvas"></div>
                        </div>
                     </div>
                     <div class="introductionGadegt">
                         <div class="gadegt"></div>
                         <div class="gadegt"></div>
                         <div class="gadegt"></div>
                     </div>
                     <div class="clear" />
                </div>
        </div>