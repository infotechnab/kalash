<!DOCTYPE HTML >
<html>
    <head>
        <title>Kalash</title>
        <link rel="stylesheet" href="<?php echo base_url()."content/styles/kalash.css" ?>" />
        <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
        <meta charset="utf-8">
<style>
#map-canvas {
margin: 0;
padding: 0;
height: 100%;
}
</style>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
<script>
var map;
function initialize() {
var mapOptions = {
zoom: 8,
center: new google.maps.LatLng(-34.397, 150.644),
mapTypeId: google.maps.MapTypeId.ROADMAP
};
map = new google.maps.Map(document.getElementById('map-canvas'),
mapOptions);
}

google.maps.event.addDomListener(window, 'load', initialize);

</script>
<style>
    @media screen and (max-width:480px)
    {
        .sliderImage{
            float: none;
            width: 100%;
        }
        .listImage{
            width: 275%;
        }
        #headerLogo,.introductionNote{
            width: 100%;
        }
        #listItem li {
            text-align: left;
            }
            .gadegt,.copyright,.design{
                float: none;
                width: 100%;
                border-top:#fff solid 2px;
            }
            .flagImg1,.flagImg2{
   
    width: 5%;
    height: 20%;
}
.flagImg1{
     margin-left: 85%;
}
      }
      @media screen and (max-width:800px)
      {
        .gadegt,.copyright,.design{
                float: none;
                width: 100%;
                border-top:#fff solid 2px;
            } 
            .flagImg1,.flagImg2{
   
    width: 4%;
    height: 16%;
}
.flagImg1{
     margin-left: 85%;
}
            
            
      }
</style>
    </head>
    
     
    <body>
        <div class="full">
        <div class="fullBody">
            <div class="topFlag"> <img class="flagImg1" src="<?php echo base_url()."content/images/flag2.png" ?>" /> <img class="flagImg2" src="<?php echo base_url()."content/images/flag1.png" ?>" />    </div>
                 <div class="fullContent">
                    <div class="header">
                        <img id="headerLogo"src="<?php echo base_url()."content/images/kalash.jpg" ?>" alt="kalash logo" width="40%" height="25%" /> 
                        <div id="fb-root"></div>
<script>(function(d, s, id) {
var js, fjs = d.getElementsByTagName(s)[0];
if (d.getElementById(id)) return;
js = d.createElement(s); js.id = id;
js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId=312833668796761";
fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

                      <!--  <img id="facebookLike" src="<?php echo base_url()."content/images/Facebook-Like-Button.png"?>" alt="facebook like" /> -->
                    </div>
                     <div class="menuList">
                         <ul id="listItem">
                             <li>Home</li>
                             <li>Restaurant</li>
                             <li>Special</li>
                             <li>Features</li>
                             <li>Services</li>
                             <li>Contact</li>
                         </ul>
                     </div>
                     
                     <div class="imageSlider">
                         <div class="smallImage">
                             <div class="listImage"><img src="<?php echo base_url()."content/images/food1.jpg" ?>" width="100%" height="40%" /></div>
                             <div class="listImage"><img src="<?php echo base_url()."content/images/food2.jpg" ?>" width="100%" height="40%"/></div>
                             <div class="listImage"><img src="<?php echo base_url()."content/images/food3.jpg" ?>" width="100%" height="40%"/></div>
                         </div>
                         <div class="sliderImage"><img src="<?php echo base_url()."content/images/slider.jpg" ?>" width="100%" height="100%"/></div>
                     </div>
                     <div class="clear"></div>           