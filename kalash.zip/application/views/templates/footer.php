 <div class="footer">
                <div class="copyright" >Copyright &COPY; 2013 Kalash Restaurant </div>
                <div class="design" > Design By : Salyani Technologies</div>
            </div>
            <div class="clear"/>
        </div>      
    </body>
</html>