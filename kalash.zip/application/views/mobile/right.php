<div class="full-right">
<div class="content">
  <div class="title-name">
  <h3> Page <?php// echo $tital; ?> </h3>
  </div>
    <div class="page-pragraph">
<?php //if((isset($image)) && (trim($image) !=='') && ($image !==0))
//{ ?>
   <!-- <img src="<?php// echo base_url();?>uploads/<?php// echo $image; ?>" alt="<?php// echo $tital; ?>" /> -->
<?php// } ?>    
    <p class="para"> This is Content Display View<?php// echo $body; ?></p>        
</div>
</div> 
</div>    
<!--//======full div close=========//-->
</div>
<div class="clear" > </div>
<div id="footer">
                 <div  id="copyright">  Copyright &copy;  2013. B&W </div> 
            
        <div class="credit"> Designed By: Salyani Technologies(p) LTD.
             
        </div>
            <div class="clear" > </div>
</div>
</body>
</html>