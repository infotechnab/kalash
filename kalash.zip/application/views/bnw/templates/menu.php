<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<div id="adminmenu">
    <ul>
        <li><?php echo anchor('bnw', 'Home') ?></li>
        <li><?php echo anchor('bnw/menu', 'Menu') ?></li>
        <li><?php echo anchor('bnw/pages', 'Pages') ?></li>
        <li><?php echo anchor('bnw/activities', 'News & Events') ?></li>
        <li><?php echo anchor('bnw/notice', 'Notice') ?></li>
        <li><?php echo anchor('bnw/gadget', 'Gadget') ?></li>
        <li><?php echo anchor('bnw/album', 'Album') ?></li>
        <li><?php echo anchor('bnw/slider','Slider') ?> </li>
        <li><?php echo anchor('bnw/blog', 'Blog') ?></li>
         <li><?php echo anchor('bnw/download', 'Download') ?></li>
        <li><?php echo anchor('bnw/setup', 'Setup') ?></li>    
   </ul>
</div>
 <hr>