
<p>Welcome to dashboard of <b> B&W </b>. All the pages, Activities, News, Alumnae and Results manages through this page.
Adding, Editing and Deleting content using this dashboard.

</p>
<p>
    This dashboard has been maintaining by <a href="http://www.salyani.com.np">Salyani Technologies (P) Ltd.</a>.<br/>
    For the support and maintenance please contact <a href="http://salyani.com.np" target="_blank">salyani Technologies</a>. 
</p>