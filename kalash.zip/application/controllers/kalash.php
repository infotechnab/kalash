<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class kalash extends CI_Controller {
 public function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('viewmodel');
    }
public function index()
    {
    
        $this->load->view('templates/header');
        $this->load->view('templates/body');
        $this->load->view('templates/footer');
        
    }
}